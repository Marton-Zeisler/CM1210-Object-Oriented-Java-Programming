// 1841485 - Marton Zeisler

interface Instruments{
	public String getInstrumentName();
	public double getInstrumentPrice();
	public String getFamousMusician();
}