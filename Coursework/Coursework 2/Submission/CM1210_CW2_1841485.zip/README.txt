How to run question 1:
	- Uncomment the println line in the main method of the Assignment.java file so the program can print out the nonstop words
	- Compile and run the Assignment.java file

How to run question 2:
	- Compile and run the Assignment.java file, the main method has two function calls that will print out the statistics for the two sorting algorithms as they perform the sorting algorithms.

How to run question 3:
	- Compile and run the MyArrayQueue.java file
